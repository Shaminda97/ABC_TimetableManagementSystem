﻿namespace ABC_TimetableManagementSystem
{


    partial class ABC_databaseDataSet
    {
        partial class TagTableDataTable
        {
        }

        partial class StudentTableDataTable
        {
        }
    }
}
