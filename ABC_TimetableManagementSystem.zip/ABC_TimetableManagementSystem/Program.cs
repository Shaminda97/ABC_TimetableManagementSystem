﻿using ABC_TimetableManagementSystem.LocationManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ABC_TimetableManagementSystem
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
<<<<<<< HEAD
            Application.Run(new Form1());
           // Application.Run(new addSuitableRoom());
=======
            Application.Run(new Form3());
            //Application.Run(new locationManagement());
>>>>>>> f9e6123aa2edf5c783885b52f208f610caa58162
        }
    }
}
